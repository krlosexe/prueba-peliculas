import React from 'react';
import Characters from '../components/Characters/Component'

function CharactersPage(props) {
  return (
      <div>
        
        <Characters props={props}/>
      </div>
  );
}

export default CharactersPage;

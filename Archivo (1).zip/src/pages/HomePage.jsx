import React from 'react';
import FilmList from '../components/FilmsList/Component'

function HomePage() {
  

return (
    <div>
		<FilmList />
    </div>

  );
}

export default HomePage;
